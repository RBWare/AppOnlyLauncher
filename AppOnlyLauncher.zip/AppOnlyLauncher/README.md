# AppOnlyLauncher
A launcher for android that is nothing more than the app tray
